<?php
$this->pageTitle = Yii::app()->name . ' - O nama';
$this->breadcrumbs = array(
    'O nama',
);
?>
<div class="container page-min-height">
    <div class="row">
        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><a href="/">Početna</a></li>
                <li class="active"><a href="">O nama</a></li>
            </ol>
        </div>
    </div>
    <h1 class="page-header">O nama</h1>

    <p>Ovo je statična stranica i njen sadržaj se može promeniti izmenom fajla: <?php echo __FILE__; ?>.</p>
</div>



